import React, { Component } from 'react';


class Register extends Component{

    constructor(props){
        super(props);
        this.state = {
            user:{email:"",password:""}
        }
    }

    onTextChange = (e,origin)=>{
        let {user} = this.state;
        switch(origin){
            case "email": this.setState({user:{...user,email:e.target.value}});break;
            case "password": this.setState({user:{...user,password:e.target.value}});break;

        }
    }

    render(){
        let {user} = this.state;
        return(
            <div className="container">
                <div class="row">
                    <div className="col-lg-6 col-md-12">
                        <h3 className = "text-center">Registration Page</h3>
                        <br>
                        <div className = "card">
                            <div className = "card-body">
                                <div className = "form-group">
                                    <label>Email</label>
                                    <input className="form-control" type="email" value={user.email} onChange={(e)=>this.onTextChange(e,"email")}/>
                                    <label>Password</label>
                                    <input className="form-control" type="password" value={user.password} onChange={(e)=>this.onTextChange(e,"password")}/>
                                    <button className="btn btn-block btn-success">Submit</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        )   
    }
}

export default Register;