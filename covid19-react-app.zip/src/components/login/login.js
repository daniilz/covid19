import React, { Component } from 'react';

import axios from "axios";

class Login extends Component{

    constructor(props){
        super(props);
        this.state = {
            user:{email:"",password:""}
        }
    }

    onTextChange = (e,origin)=>{
        let {user} = this.state;
        switch(origin){
            case "email": this.setState({user:{...user,email:e.target.value}});break;
            case "password": this.setState({user:{...user,password:e.target.value}});break;

        }
    }

    submitRegister = async =>{
        let {user} = this.state;
        let formData = new FormData();

        if(user.email === "" || user.password==="") {
            alert("these fields are required!");
        } else{

            let url = "https://localhost/covid19-php/register.php";
            axios({
                method: 'post',
                url: url,
                data: formData
              }).then((response)=>{
                  console.log(response);
              })
        }

        formData.append("email",user.email);
        formData.append("password",user.password);
    }

    render(){
        let {user} = this.state;
        return(
            <div className="container">
                <div class="row">
                    <div className="col-lg-6 col-md-12">
                        <h3 className = "text-center">Login Page</h3>
                        <br>
                        <div className = "card">
                            <div className = "card-body">
                                <div className = "form-group">
                                    <label>Email</label>
                                    <input className="form-control" type="email" value={user.email} onChange={(e)=>this.onTextChange(e,"email")}/>
                                    <label>Password</label>
                                    <input className="form-control" type="password" value={user.password} onChange={(e)=>this.onTextChange(e,"password")}/>
                                    <button className="btn btn-block btn-success" onClick={()=>{this.submitRegister();}}>Submit</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        )   
    }
}

export default Login;