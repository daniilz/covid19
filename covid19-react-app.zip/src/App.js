import React, { Component } from 'react';
import './App.css';

import axios from 'axios';

import Home from "./components/home/home";
import Register from "./components/register/register";
import Login from "./components/login/login";
import { Router } from 'react-router';

class App extends Component{

  constructor(props){
    super(props);
  }
  
  render(){
    return(
      <Router>
        <div>
          <Switch>
            <Route exact path="/">
              <Home />            
            </Route>
            <Route path="/register">
              <Register />            
            </Route> 
            <Route path="/login">
              <Login />            
            </Route>                        
          </Switch>
        </div>
      </Router>
    )
  }

}

export default App;
